package dk.zai.anticheat.data;

/**
 * Punishment types - mirrors AdvancedBan 2.3.0.
 * The {@code permanent} flag tells the layout system whether to render
 * a duration or "permanent" placeholder.
 */
public enum PunishmentType {
    BAN("Ban", true, true),
    TEMP_BAN("Tempban", false, true),
    IP_BAN("Ipban", true, true),
    TEMP_IP_BAN("Tempipban", false, true),
    MUTE("Mute", true, false),
    TEMP_MUTE("Tempmute", false, false),
    KICK("Kick", true, false),
    WARN("Warn", true, false),
    TEMP_WARN("Tempwarn", false, false),
    NOTE("Note", true, false);

    private final String configKey;
    private final boolean permanent;
    private final boolean banning;

    PunishmentType(String configKey, boolean permanent, boolean banning) {
        this.configKey = configKey;
        this.permanent = permanent;
        this.banning = banning;
    }

    public String getConfigKey() { return configKey; }
    public boolean isPermanent() { return permanent; }
    public boolean isBanning() { return banning; }

    /** Whether this type has a duration (everything except the non-TEMP_* base types
     *  that don't support durations). KICK and NOTE have no duration either. */
    public boolean hasDuration() {
        return name().startsWith("TEMP_");
    }

    public boolean isIpVariant() {
        return this == IP_BAN || this == TEMP_IP_BAN;
    }

    public boolean isMute() {
        return this == MUTE || this == TEMP_MUTE;
    }

    public boolean isWarn() {
        return this == WARN || this == TEMP_WARN;
    }

    public boolean isNote() {
        return this == NOTE;
    }

    public boolean isBan() {
        return banning;
    }

    public String basicName() {
        return name().replace("TEMP_", "TEMP ").replace("_", " ");
    }
}

package dk.zai.anticheat.data;

import java.util.UUID;

/**
 * Per-player anti-cheat state (transient). Punishments themselves
 * are stored as {@link Punishment} records by PunishmentManager.
 *
 * This class holds: violation level, transient flags such as
 * wind-charge immunity windows, AutoClicker / Timer / packet-flood
 * sample buffers, and per-check timing windows.
 */
public class PlayerData {

    private final UUID uuid;
    private String lastName;
    private String lastIp = "";

    private int violationLevel = 0;
    private int totalFlags = 0;
    private long lastFlagTime = 0;

    // Transient
    private long windChargeImmunityUntil = 0L;

    // AutoClicker samples
    private final long[] clickTimes = new long[30];
    private int clickIndex = 0;
    private int clickCount = 0;

    // Timer samples
    private final long[] moveTimes = new long[40];
    private int moveIndex = 0;
    private int moveCount = 0;

    // KillAura / MultiAura
    private long lastCombatTime = 0L;
    private final java.util.List<UUID> recentTargets = new java.util.ArrayList<>();
    private long recentTargetWindow = 0L;

    // Packet flood
    private long packetWindowStart = 0L;
    private int packetCount = 0;

    // FastPlace / FastBreak
    private long lastPlaceTime = 0L;
    private long lastBreakTime = 0L;
    private int scaffoldCount = 0;
    private long scaffoldWindowStart = 0L;

    // NoFall
    private double lastFallDistance = 0D;
    private boolean lastReportedGround = true;

    // AutoEat / AutoArmor
    private long eatStart = 0L;
    private long lastArmorPickup = 0L;

    public PlayerData(UUID uuid) { this.uuid = uuid; }

    public UUID getUuid() { return uuid; }
    public String getLastName() { return lastName; }
    public void setLastName(String n) { this.lastName = n; }
    public String getLastIp() { return lastIp; }
    public void setLastIp(String ip) { this.lastIp = ip; }

    public int getViolationLevel() { return violationLevel; }
    public void setViolationLevel(int vl) { this.violationLevel = Math.max(0, vl); }
    public void incrementVL(int amount) {
        this.violationLevel += amount;
        this.totalFlags += amount;
        this.lastFlagTime = System.currentTimeMillis();
    }
    public void resetVL() { this.violationLevel = 0; }
    public int getTotalFlags() { return totalFlags; }
    public long getLastFlagTime() { return lastFlagTime; }

    public boolean isWindChargeImmune() { return System.currentTimeMillis() < windChargeImmunityUntil; }
    public void grantWindChargeImmunity(long ms) { this.windChargeImmunityUntil = System.currentTimeMillis() + ms; }

    // --- AutoClicker ---
    public void recordClick() {
        clickTimes[clickIndex] = System.currentTimeMillis();
        clickIndex = (clickIndex + 1) % clickTimes.length;
        if (clickCount < clickTimes.length) clickCount++;
    }
    public long[] getClickSamples() {
        long[] out = new long[clickCount];
        int start = (clickIndex - clickCount + clickTimes.length) % clickTimes.length;
        for (int i = 0; i < clickCount; i++) out[i] = clickTimes[(start + i) % clickTimes.length];
        return out;
    }
    public int getClickCount() { return clickCount; }

    // --- Timer ---
    public void recordMove() {
        moveTimes[moveIndex] = System.currentTimeMillis();
        moveIndex = (moveIndex + 1) % moveTimes.length;
        if (moveCount < moveTimes.length) moveCount++;
    }
    public long[] getMoveSamples() {
        long[] out = new long[moveCount];
        int start = (moveIndex - moveCount + moveTimes.length) % moveTimes.length;
        for (int i = 0; i < moveCount; i++) out[i] = moveTimes[(start + i) % moveTimes.length];
        return out;
    }
    public int getMoveCount() { return moveCount; }

    // --- KillAura / MultiAura ---
    public long getLastCombatTime() { return lastCombatTime; }
    public void setLastCombatTime(long t) { this.lastCombatTime = t; }
    public java.util.List<UUID> getRecentTargets() { return recentTargets; }
    public long getRecentTargetWindow() { return recentTargetWindow; }
    public void setRecentTargetWindow(long t) { this.recentTargetWindow = t; }

    // --- Packet flood ---
    public long getPacketWindowStart() { return packetWindowStart; }
    public void setPacketWindowStart(long t) { this.packetWindowStart = t; }
    public int getPacketCount() { return packetCount; }
    public void setPacketCount(int c) { this.packetCount = c; }
    public void incrementPacketCount() { this.packetCount++; }

    // --- FastPlace / Scaffolding ---
    public long getLastPlaceTime() { return lastPlaceTime; }
    public void setLastPlaceTime(long t) { this.lastPlaceTime = t; }
    public long getLastBreakTime() { return lastBreakTime; }
    public void setLastBreakTime(long t) { this.lastBreakTime = t; }
    public int getScaffoldCount() { return scaffoldCount; }
    public void setScaffoldCount(int c) { this.scaffoldCount = c; }
    public void incrementScaffold() { this.scaffoldCount++; }
    public long getScaffoldWindowStart() { return scaffoldWindowStart; }
    public void setScaffoldWindowStart(long t) { this.scaffoldWindowStart = t; }

    // --- NoFall ---
    public double getLastFallDistance() { return lastFallDistance; }
    public void setLastFallDistance(double d) { this.lastFallDistance = d; }
    public boolean isLastReportedGround() { return lastReportedGround; }
    public void setLastReportedGround(boolean g) { this.lastReportedGround = g; }

    // --- AutoEat / AutoArmor ---
    public long getEatStart() { return eatStart; }
    public void setEatStart(long t) { this.eatStart = t; }
    public long getLastArmorPickup() { return lastArmorPickup; }
    public void setLastArmorPickup(long t) { this.lastArmorPickup = t; }
}

package dk.zai.anticheat.data;

/**
 * Immutable punishment record persisted to data.yml.
 * Mirrors AdvancedBan: each punishment has an auto-increment ID, an
 * operator, a target (UUID + name + IP), a start timestamp, an end
 * timestamp (-1 = permanent), and a reason.
 *
 * Notes are also stored as Punishment records of type NOTE so the
 * same history/pagination code works for everything.
 */
public class Punishment {

    private final long id;
    private final PunishmentType type;
    private final String targetName;
    private final String targetUuid;
    private final String targetIp;
    private final String operator;
    private final String operatorUuid;
    private final long start;
    private final long end;            // -1 = permanent, 0 = no duration (kick/note)
    private String reason;
    private boolean silent;

    public Punishment(long id, PunishmentType type, String targetName, String targetUuid,
                      String targetIp, String operator, String operatorUuid,
                      long start, long end, String reason, boolean silent) {
        this.id = id;
        this.type = type;
        this.targetName = targetName;
        this.targetUuid = targetUuid;
        this.targetIp = targetIp;
        this.operator = operator;
        this.operatorUuid = operatorUuid;
        this.start = start;
        this.end = end;
        this.reason = reason;
        this.silent = silent;
    }

    public long getId() { return id; }
    public String getHexId() { return Long.toHexString(id).toUpperCase(); }
    public PunishmentType getType() { return type; }
    public String getTargetName() { return targetName; }
    public String getTargetUuid() { return targetUuid; }
    public String getTargetIp() { return targetIp; }
    public String getOperator() { return operator; }
    public String getOperatorUuid() { return operatorUuid; }
    public long getStart() { return start; }
    public long getEnd() { return end; }
    public String getReason() { return reason; }
    public void setReason(String r) { this.reason = r; }
    public boolean isSilent() { return silent; }

    public boolean isPermanent() { return end == -1L; }

    public boolean isActive() {
        if (type == KICK_LIKE) return false;
        if (isPermanent()) return true;
        return end == 0L || System.currentTimeMillis() < end;
    }
    private static final PunishmentType KICK_LIKE = PunishmentType.KICK;

    public boolean isExpired() {
        if (type == PunishmentType.KICK || type == PunishmentType.NOTE) return true;
        if (isPermanent()) return false;
        return end > 0 && System.currentTimeMillis() >= end;
    }

    public long getRemainingMillis() {
        if (isPermanent()) return -1L;
        if (end <= 0) return 0L;
        return Math.max(0L, end - System.currentTimeMillis());
    }
}

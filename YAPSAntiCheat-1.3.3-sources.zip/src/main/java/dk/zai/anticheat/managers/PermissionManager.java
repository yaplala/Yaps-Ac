package dk.zai.anticheat.managers;

import dk.zai.anticheat.AntiCheatPlugin;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

import java.util.List;

/**
 * Handles all permission/exempt checks for the AdvancedBan-style system.
 *
 * Permission hierarchy (highest precedence first):
 *   1. sender.isOp()                -> always allow
 *   2. ab.all OR ab.*                -> wildcard for every ab.<x>
 *   3. ab.<specific>                 -> e.g. ab.ban, ab.tempban
 *   4. ab.<command>.dur.<N>          -> duration cap tiers for temp commands
 *   5. ab.<command>.dur.max          -> bypass duration cap
 *
 * Exempt players (configured in config.yml exempt-players) cannot be
 * punished by anyone except via console.
 */
public class PermissionManager {

    private final AntiCheatPlugin plugin;

    public PermissionManager(AntiCheatPlugin plugin) {
        this.plugin = plugin;
    }

    public boolean has(CommandSender sender, String node) {
        if (sender == null) return false;
        if (sender.isOp()) return true;
        if (sender.hasPermission("ab.all")) return true;
        if (plugin.getConfig().getBoolean("punishment.enable-all-permission-nodes", true)
                && sender.hasPermission("ab.*")) return true;
        return sender.hasPermission(node);
    }

    public boolean hasBan(CommandSender s)        { return has(s, "ab.ban"); }
    public boolean hasTempban(CommandSender s)    { return has(s, "ab.tempban"); }
    public boolean hasIpban(CommandSender s)      { return has(s, "ab.ipban"); }
    public boolean hasTempipban(CommandSender s)  { return has(s, "ab.tempipban"); }
    public boolean hasMute(CommandSender s)       { return has(s, "ab.mute"); }
    public boolean hasTempmute(CommandSender s)   { return has(s, "ab.tempmute"); }
    public boolean hasKick(CommandSender s)       { return has(s, "ab.kick"); }
    public boolean hasWarn(CommandSender s)       { return has(s, "ab.warn"); }
    public boolean hasTempwarn(CommandSender s)   { return has(s, "ab.tempwarn"); }
    public boolean hasNote(CommandSender s)       { return has(s, "ab.note"); }
    public boolean hasUnban(CommandSender s)      { return has(s, "ab.unban"); }
    public boolean hasUnmute(CommandSender s)     { return has(s, "ab.unmute"); }
    public boolean hasUnwarn(CommandSender s)     { return has(s, "ab.unwarn"); }
    public boolean hasUnnote(CommandSender s)     { return has(s, "ab.unnote"); }
    public boolean hasUnpunish(CommandSender s)   { return has(s, "ab.unpunish"); }
    public boolean hasChangeReason(CommandSender s){return has(s, "ab.change-reason"); }
    public boolean hasBanlist(CommandSender s)    { return has(s, "ab.banlist"); }
    public boolean hasHistory(CommandSender s)    { return has(s, "ab.history"); }
    public boolean hasNotes(CommandSender s)      { return has(s, "ab.notes"); }
    public boolean hasCheck(CommandSender s)      { return has(s, "ab.check"); }
    public boolean hasNotify(CommandSender s)     { return has(s, "ab.notify"); }
    public boolean hasNotifySilent(CommandSender s){return has(s, "ab.notify.silent"); }
    public boolean hasUndoNotify(CommandSender s) { return has(s, "ab.undo.notify"); }
    public boolean hasUndoAll(CommandSender s)    { return has(s, "ab.undo.all"); }

    /** Self warns/notes: always allowed for the player themselves. */
    public boolean canViewWarnsOf(CommandSender s, String targetName) {
        if (s == null) return false;
        if (s.isOp()) return true;
        if (s instanceof Player p && p.getName().equalsIgnoreCase(targetName)) {
            return p.hasPermission("ab.warns.self") || p.hasPermission("ab.warns.own");
        }
        return has(s, "ab.warns.other");
    }

    /** Returns the max duration (in seconds) the sender can use for the given temp command.
     *  -1 means unlimited (bypass). 0 means no permission at all. */
    public long getMaxDuration(CommandSender sender, String command) {
        if (sender == null) return 0;
        if (sender.isOp()) return -1;
        if (sender.hasPermission("ab." + command + ".dur.max")) return -1;

        ConfigurationSection perms = plugin.getConfig().getConfigurationSection("punishment.temp-perms");
        if (perms == null) return -1; // no caps configured = unlimited

        long max = 0;
        for (String key : perms.getKeys(false)) {
            try {
                int tier = Integer.parseInt(key);
                long seconds = perms.getLong(key);
                if (sender.hasPermission("ab." + command + ".dur." + tier) && seconds > max) {
                    max = seconds;
                }
            } catch (NumberFormatException ignored) {}
        }
        return max == 0 ? 0 : max;
    }

    /** Check if the target name is in the exempt list. Console can always override. */
    public boolean isExempt(String targetName) {
        List<String> exempt = plugin.getConfig().getStringList("punishment.exempt-players");
        for (String e : exempt) {
            if (e.equalsIgnoreCase(targetName)) return true;
        }
        return false;
    }
}

package dk.zai.anticheat.managers;

import dk.zai.anticheat.AntiCheatPlugin;
import dk.zai.anticheat.data.PlayerData;
import dk.zai.anticheat.data.Punishment;
import dk.zai.anticheat.data.PunishmentType;
import net.kyori.adventure.text.Component;
import org.bukkit.BanList;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.UUID;

/**
 * Issues AdvancedBan-style punishments, kicks/bans players, broadcasts
 * notifications to staff with ab.notify (or ab.notify.silent for -s flags),
 * and triggers configured WarnActions when warn counts cross thresholds.
 */
public class PunishmentManager {

    private final AntiCheatPlugin plugin;

    public PunishmentManager(AntiCheatPlugin plugin) {
        this.plugin = plugin;
    }

    public LayoutsManager getLayouts() { return plugin.getLayoutsManager(); }
    public PermissionManager getPerms() { return plugin.getPermissionManager(); }

    // =====================================================================
    // Issue a punishment
    // =====================================================================

    /**
     * Core method. Creates a Punishment record, persists it, kicks the
     * player if needed, and broadcasts the notification message.
     *
     * @return the created Punishment, or null if the player is exempt
     *         or already punished with the same category.
     */
    public Punishment issue(PunishmentType type, String targetName, String targetIp,
                             long durationMillis, String reason, CommandSender operator,
                             boolean silent) {
        // Resolve target UUID
        UUID targetUuid = plugin.getDataManager().getCachedUuid(targetName);
        if (targetUuid == null) {
            OfflinePlayer op = Bukkit.getOfflinePlayer(targetName);
            targetUuid = op.getUniqueId();
            if (targetUuid != null) plugin.getDataManager().cacheName(targetName, targetUuid);
        }
        if (targetUuid == null) return null;

        // Exempt check (console can override)
        if (!(operator instanceof ConsoleCommandSender) && getPerms().isExempt(targetName)) {
            operator.sendMessage(getLayouts().renderMessage(
                    type.getConfigKey() + ".Exempt",
                    new Punishment(0, type, targetName, targetUuid.toString(), targetIp,
                            operator.getName(), getOpUuid(operator),
                            System.currentTimeMillis(), 0, reason, silent)));
            return null;
        }

        // Already banned / already muted?
        if (type.isBanning()) {
            Punishment existing = plugin.getDataManager().getActiveBan(targetUuid);
            if (existing != null) {
                operator.sendMessage(getLayouts().renderMessage(
                        type.getConfigKey() + ".AlreadyDone",
                        existing));
                return null;
            }
        } else if (type.isMute()) {
            Punishment existing = plugin.getDataManager().getActiveMute(targetUuid);
            if (existing != null) {
                operator.sendMessage(getLayouts().renderMessage(
                        type.getConfigKey() + ".AlreadyDone",
                        existing));
                return null;
            }
        }

        long start = System.currentTimeMillis();
        long end;
        if (type.isPermanent() || (type.hasDuration() && durationMillis < 0)) {
            end = -1L;
        } else if (type.hasDuration()) {
            end = start + durationMillis;
        } else {
            end = 0L; // kick / note: no duration
        }

        Player online = Bukkit.getPlayer(targetUuid);

        long id = plugin.getDataManager().nextPunishmentId();
        String opName = (operator == null) ? "CONSOLE" : operator.getName();
        String opUuid = getOpUuid(operator);

        // For IP-ban variants issued with a player name (no raw IP given),
        // look up the player's last known IP from cache.
        if (type.isIpVariant() && (targetIp == null || targetIp.isEmpty())) {
            PlayerData pd = plugin.getDataManager().get(targetUuid);
            if (pd != null && !pd.getLastIp().isEmpty()) {
                targetIp = pd.getLastIp();
            } else if (online != null && online.getAddress() != null) {
                targetIp = online.getAddress().getAddress().getHostAddress();
            }
        }

        Punishment p = new Punishment(id, type, targetName, targetUuid.toString(),
                targetIp != null ? targetIp : "", opName, opUuid,
                start, end, reason, silent);
        plugin.getDataManager().addPunishment(p);
        plugin.getDataManager().cacheName(targetName, targetUuid);
        if (targetIp != null && !targetIp.isEmpty()) {
            plugin.getDataManager().cacheIp(targetIp, targetUuid);
        }

        // Apply immediate effects (kick / disconnect)
        if (type.isBanning()) {
            Component screen = getLayouts().renderLayout(
                    resolveLayout(type, reason), p);
            if (online != null) {
                Bukkit.getScheduler().runTask(plugin, () -> online.kick(screen));
            }
            // Also add to vanilla ban list so offline players can't log in
            if (type.isIpVariant() && targetIp != null && !targetIp.isEmpty()) {
                Bukkit.getBanList(BanList.Type.IP).addBan(targetIp, reason, null, opName);
            } else {
                Bukkit.getBanList(BanList.Type.NAME).addBan(targetName, reason, null, opName);
            }
        } else if (type == PunishmentType.KICK) {
            if (online != null) {
                Component screen = getLayouts().renderLayout(resolveLayout(type, reason), p);
                Bukkit.getScheduler().runTask(plugin, () -> online.kick(screen));
            }
        }

        // Notify operator (success message)
        operator.sendMessage(getLayouts().renderMessage(type.getConfigKey() + ".Done", p));

        // Notify staff (broadcast or silent)
        broadcastNotification(type, p, silent);

        // Trigger WarnActions for warns
        if (type.isWarn()) {
            int count = plugin.getDataManager().getActiveWarns(targetUuid).size();
            triggerWarnActions(targetName, count, reason);
        }

        plugin.getDataManager().save();
        return p;
    }

    /** Resolves the layout: @CustomLayout, default Reason, or default Layout list. */
    private List<String> resolveLayout(PunishmentType type, String reason) {
        if (reason != null && reason.startsWith("@")) {
            String name = reason.substring(1);
            List<String> custom = getLayouts().getCustomMessageLayout(name);
            if (custom != null) return custom;
        }
        return getLayouts().getMessageList(type.getConfigKey() + ".Layout");
    }

    private void broadcastNotification(PunishmentType type, Punishment p, boolean silent) {
        List<String> notifLines = getLayouts().getMessageList(type.getConfigKey() + ".Notification");
        if (notifLines.isEmpty()) {
            String single = getLayouts().getMessage(type.getConfigKey() + ".Notification");
            if (!single.startsWith("&cMissing")) notifLines = List.of(single);
        }
        if (notifLines.isEmpty()) return;

        Component msg = getLayouts().renderLayout(notifLines, p);
        String perm = silent ? "ab.notify.silent" : "ab.notify";
        for (Player staff : Bukkit.getOnlinePlayers()) {
            if (staff.hasPermission(perm)) staff.sendMessage(msg);
        }
        Bukkit.getConsoleSender().sendMessage(msg);
    }

    // =====================================================================
    // Undo / revoke
    // =====================================================================

    public void revokeBan(String targetName, CommandSender operator) {
        UUID uuid = plugin.getDataManager().getCachedUuid(targetName);
        if (uuid == null) {
            OfflinePlayer op = Bukkit.getOfflinePlayer(targetName);
            uuid = op.getUniqueId();
        }
        if (uuid == null) {
            operator.sendMessage(getLayouts().renderMessage("Unban.NotPunished",
                    dummy("Unban", targetName, operator)));
            return;
        }
        Punishment active = plugin.getDataManager().getActiveBan(uuid);
        if (active == null) {
            operator.sendMessage(getLayouts().renderMessage("Unban.NotPunished",
                    dummy("Unban", targetName, operator)));
            return;
        }
        // Mark expired by removing it (AdvancedBan keeps history but marks removed).
        plugin.getDataManager().removePunishment(active.getId());
        Bukkit.getBanList(BanList.Type.NAME).pardon(targetName);
        if (!active.getTargetIp().isEmpty()) {
            Bukkit.getBanList(BanList.Type.IP).pardon(active.getTargetIp());
        }
        operator.sendMessage(getLayouts().renderMessage("Unban.Done",
                dummy("Unban", targetName, operator)));

        // Notify staff
        String undo = getLayouts().getMessage("Unban.Notification");
        Component msg = getLayouts().renderList(List.of(undo.replace("%OPERATOR%", operator.getName())
                .replace("%NAME%", targetName)));
        for (Player s : Bukkit.getOnlinePlayers()) {
            if (s.hasPermission("ab.undo.notify")) s.sendMessage(msg);
        }
        plugin.getDataManager().save();
    }

    public void revokeMute(String targetName, CommandSender operator) {
        UUID uuid = plugin.getDataManager().getCachedUuid(targetName);
        if (uuid == null) {
            OfflinePlayer op = Bukkit.getOfflinePlayer(targetName);
            uuid = op.getUniqueId();
        }
        if (uuid == null) {
            operator.sendMessage(getLayouts().renderMessage("Unmute.NotPunished",
                    dummy("Unmute", targetName, operator)));
            return;
        }
        Punishment active = plugin.getDataManager().getActiveMute(uuid);
        if (active == null) {
            operator.sendMessage(getLayouts().renderMessage("Unmute.NotPunished",
                    dummy("Unmute", targetName, operator)));
            return;
        }
        plugin.getDataManager().removePunishment(active.getId());
        operator.sendMessage(getLayouts().renderMessage("Unmute.Done",
                dummy("Unmute", targetName, operator)));

        String undo = getLayouts().getMessage("Unmute.Notification");
        Component msg = getLayouts().renderList(List.of(undo.replace("%OPERATOR%", operator.getName())
                .replace("%NAME%", targetName)));
        for (Player s : Bukkit.getOnlinePlayers()) {
            if (s.hasPermission("ab.undo.notify")) s.sendMessage(msg);
        }
        plugin.getDataManager().save();
    }

    public void revokeById(long id, CommandSender operator) {
        Punishment p = plugin.getDataManager().getPunishmentById(id);
        if (p == null) {
            operator.sendMessage(getLayouts().renderList(List.of(
                    getLayouts().getMessage("Unpunish.NotPunished").replace("%ID%", String.valueOf(id)))));
            return;
        }
        plugin.getDataManager().removePunishment(id);
        // Pardon from vanilla ban lists if applicable
        if (p.getType().isBanning()) {
            Bukkit.getBanList(BanList.Type.NAME).pardon(p.getTargetName());
            if (!p.getTargetIp().isEmpty()) {
                Bukkit.getBanList(BanList.Type.IP).pardon(p.getTargetIp());
            }
        }
        operator.sendMessage(getLayouts().renderList(List.of(
                getLayouts().getMessage("Unpunish.Done").replace("%ID%", String.valueOf(id)))));
        plugin.getDataManager().save();
    }

    public void changeReason(long id, String newReason, CommandSender operator) {
        Punishment p = plugin.getDataManager().getPunishmentById(id);
        if (p == null) {
            operator.sendMessage(getLayouts().renderList(List.of(
                    getLayouts().getMessage("ChangeReason.NotPunished").replace("%ID%", String.valueOf(id)))));
            return;
        }
        p.setReason(newReason);
        operator.sendMessage(getLayouts().renderList(List.of(
                getLayouts().getMessage("ChangeReason.Done")
                        .replace("%ID%", String.valueOf(id))
                        .replace("%REASON%", newReason))));
        plugin.getDataManager().save();
    }

    // =====================================================================
    // WarnActions: run configured commands when warn count crosses thresholds
    // =====================================================================

    private void triggerWarnActions(String targetName, int warnCount, String reason) {
        var section = plugin.getConfig().getConfigurationSection("punishment.warn-actions");
        if (section == null) return;
        // Find the highest configured threshold <= warnCount that we haven't run yet
        int best = -1;
        for (String k : section.getKeys(false)) {
            try {
                int n = Integer.parseInt(k);
                if (n == warnCount) { best = n; break; }
            } catch (NumberFormatException ignored) {}
        }
        if (best < 0) return;
        String cmd = section.getString(String.valueOf(best));
        if (cmd == null || cmd.isEmpty()) return;
        cmd = cmd.replace("%PLAYER%", targetName)
                 .replace("%REASON%", reason)
                 .replace("%COUNT%", String.valueOf(warnCount));
        final String finalCmd = cmd;
        Bukkit.getScheduler().runTask(plugin, () ->
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), finalCmd));
    }

    // =====================================================================
    // Anti-cheat integration: apply a punishment from the punishment-steps ladder
    // =====================================================================

    public void applyFromAntiCheatStep(Player player, String action, int durationMinutes, String checkName) {
        String opName = "ZAntiCheat";
        String opUuid = "";
        switch (action.toUpperCase()) {
            case "WARN" -> {
                player.sendMessage(getLayouts().renderList(List.of(
                        getLayouts().getMessage("Warn.Layout")
                                .replace("%PREFIX%", getLayouts().getPrefix())
                                .replace("%REASON%", checkName)
                                .replace("%COUNT%", String.valueOf(
                                        plugin.getDataManager().getActiveWarns(player.getUniqueId()).size())))));
            }
            case "MUTE" -> issue(PunishmentType.MUTE, player.getName(), player.getAddress().getAddress().getHostAddress(),
                    durationMinutes > 0 ? durationMinutes * 60_000L : -1L,
                    checkName, consoleOp(), false);
            case "KICK" -> issue(PunishmentType.KICK, player.getName(), null, 0L,
                    checkName, consoleOp(), false);
            case "BAN"  -> issue(durationMinutes < 0 ? PunishmentType.BAN : PunishmentType.TEMP_BAN,
                    player.getName(), player.getAddress().getAddress().getHostAddress(),
                    durationMinutes > 0 ? durationMinutes * 60_000L : -1L,
                    checkName, consoleOp(), false);
        }
    }

    private CommandSender consoleOp() {
        return Bukkit.getConsoleSender();
    }

    private String getOpUuid(CommandSender s) {
        if (s instanceof Player p) return p.getUniqueId().toString();
        return "";
    }

    private Punishment dummy(String type, String name, CommandSender op) {
        return new Punishment(0, PunishmentType.BAN, name, "", "",
                op == null ? "CONSOLE" : op.getName(), getOpUuid(op),
                System.currentTimeMillis(), 0L, "", false);
    }
}

package dk.zai.anticheat.managers;

import dk.zai.anticheat.AntiCheatPlugin;
import dk.zai.anticheat.data.PlayerData;
import dk.zai.anticheat.data.Punishment;
import dk.zai.anticheat.data.PunishmentType;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Loads/stores player anti-cheat state AND full punishment history
 * to data.yml. Punishments are stored under the "punishments" key with
 * auto-increment IDs.
 */
public class DataManager {

    private final AntiCheatPlugin plugin;
    private final File dataFile;
    private FileConfiguration data;
    private final Map<UUID, PlayerData> players = new HashMap<>();
    private final List<Punishment> punishments = new ArrayList<>();
    private final AtomicLong nextId = new AtomicLong(1);

    // Cache: name -> UUID, ip -> Set<UUID>
    private final Map<String, UUID> nameToUuid = new HashMap<>();
    private final Map<String, Set<UUID>> ipToUuids = new HashMap<>();

    public DataManager(AntiCheatPlugin plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "data.yml");
        if (!dataFile.exists()) {
            plugin.getDataFolder().mkdirs();
            try { dataFile.createNewFile(); } catch (IOException e) {
                plugin.getLogger().severe("Could not create data.yml: " + e.getMessage());
            }
        }
        this.data = YamlConfiguration.loadConfiguration(dataFile);
        loadAll();
    }

    public PlayerData get(UUID uuid) { return players.computeIfAbsent(uuid, PlayerData::new); }

    public PlayerData getByName(String name) {
        UUID uuid = nameToUuid.get(name.toLowerCase());
        if (uuid != null) return get(uuid);
        OfflinePlayer op = Bukkit.getOfflinePlayer(name);
        if (op == null || op.getUniqueId() == null) return null;
        return get(op.getUniqueId());
    }

    public UUID getCachedUuid(String name) {
        return nameToUuid.get(name.toLowerCase());
    }

    public Set<UUID> getUuidsForIp(String ip) {
        return ipToUuids.getOrDefault(ip, Collections.emptySet());
    }

    public void cacheName(String name, UUID uuid) {
        nameToUuid.put(name.toLowerCase(), uuid);
    }

    public void cacheIp(String ip, UUID uuid) {
        if (ip == null || ip.isEmpty()) return;
        ipToUuids.computeIfAbsent(ip, k -> new HashSet<>()).add(uuid);
    }

    // =====================================================================
    // Punishment history
    // =====================================================================

    public List<Punishment> getAllPunishments() {
        return Collections.unmodifiableList(punishments);
    }

    public Punishment getPunishmentById(long id) {
        for (Punishment p : punishments) if (p.getId() == id) return p;
        return null;
    }

    public long nextPunishmentId() {
        return nextId.getAndIncrement();
    }

    public void addPunishment(Punishment p) {
        punishments.add(p);
    }

    public void removePunishment(long id) {
        punishments.removeIf(p -> p.getId() == id);
    }

    /** All punishments targeting a given player UUID (current + history). */
    public List<Punishment> getHistory(UUID uuid) {
        List<Punishment> out = new ArrayList<>();
        for (Punishment p : punishments) {
            if (uuid.toString().equals(p.getTargetUuid())) out.add(p);
        }
        return out;
    }

    /** All punishments targeting a given IP. */
    public List<Punishment> getHistoryByIp(String ip) {
        List<Punishment> out = new ArrayList<>();
        for (Punishment p : punishments) {
            if (ip.equals(p.getTargetIp())) out.add(p);
        }
        return out;
    }

    /** Active ban for a given player UUID (or null). */
    public Punishment getActiveBan(UUID uuid) {
        for (Punishment p : punishments) {
            if (!p.getType().isBanning()) continue;
            if (!uuid.toString().equals(p.getTargetUuid())) continue;
            if (!p.isExpired()) return p;
        }
        // Also check IP-based bans
        PlayerData pd = players.get(uuid);
        if (pd != null && !pd.getLastIp().isEmpty()) {
            for (Punishment p : punishments) {
                if (!p.getType().isBanning() || !p.getType().isIpVariant()) continue;
                if (!pd.getLastIp().equals(p.getTargetIp())) continue;
                if (!p.isExpired()) return p;
            }
        }
        return null;
    }

    /** Active mute for a given player UUID (or null). */
    public Punishment getActiveMute(UUID uuid) {
        for (Punishment p : punishments) {
            if (!p.getType().isMute()) continue;
            if (!uuid.toString().equals(p.getTargetUuid())) continue;
            if (!p.isExpired()) return p;
        }
        return null;
    }

    /** Active warns for a given player UUID. */
    public List<Punishment> getActiveWarns(UUID uuid) {
        List<Punishment> out = new ArrayList<>();
        for (Punishment p : punishments) {
            if (!p.getType().isWarn()) continue;
            if (!uuid.toString().equals(p.getTargetUuid())) continue;
            if (!p.isExpired()) out.add(p);
        }
        return out;
    }

    public List<Punishment> getActiveBans() {
        List<Punishment> out = new ArrayList<>();
        for (Punishment p : punishments) {
            if (p.getType().isBanning() && !p.isExpired()) out.add(p);
        }
        return out;
    }

    public List<Punishment> getNotes(UUID uuid) {
        List<Punishment> out = new ArrayList<>();
        for (Punishment p : punishments) {
            if (!p.getType().isNote()) continue;
            if (uuid.toString().equals(p.getTargetUuid())) out.add(p);
        }
        return out;
    }

    // =====================================================================
    // Persistence
    // =====================================================================

    private void loadAll() {
        // Player VL data
        ConfigurationSection root = data.getConfigurationSection("players");
        if (root != null) {
            for (String key : root.getKeys(false)) {
                try {
                    UUID uuid = UUID.fromString(key);
                    ConfigurationSection sec = root.getConfigurationSection(key);
                    if (sec == null) continue;
                    PlayerData pd = new PlayerData(uuid);
                    pd.setLastName(sec.getString("name", ""));
                    pd.setLastIp(sec.getString("ip", ""));
                    pd.setViolationLevel(sec.getInt("violation-level", 0));
                    players.put(uuid, pd);
                    if (!pd.getLastName().isEmpty()) cacheName(pd.getLastName(), uuid);
                    if (!pd.getLastIp().isEmpty()) cacheIp(pd.getLastIp(), uuid);
                } catch (IllegalArgumentException ignored) {}
            }
        }

        // Punishments
        ConfigurationSection puns = data.getConfigurationSection("punishments");
        long maxId = 0;
        if (puns != null) {
            for (String key : puns.getKeys(false)) {
                try {
                    long id = Long.parseLong(key);
                    ConfigurationSection sec = puns.getConfigurationSection(key);
                    if (sec == null) continue;
                    PunishmentType type = PunishmentType.valueOf(sec.getString("type", "BAN"));
                    Punishment p = new Punishment(
                            id, type,
                            sec.getString("target-name", ""),
                            sec.getString("target-uuid", ""),
                            sec.getString("target-ip", ""),
                            sec.getString("operator", "CONSOLE"),
                            sec.getString("operator-uuid", ""),
                            sec.getLong("start", System.currentTimeMillis()),
                            sec.getLong("end", -1L),
                            sec.getString("reason", ""),
                            sec.getBoolean("silent", false));
                    punishments.add(p);
                    if (id > maxId) maxId = id;
                } catch (Exception ignored) {}
            }
        }
        nextId.set(maxId + 1);
        plugin.getLogger().info("Loaded " + players.size() + " players, "
                + punishments.size() + " punishments from data.yml.");
    }

    public synchronized void save() {
        // Player data
        for (Map.Entry<UUID, PlayerData> e : players.entrySet()) {
            PlayerData pd = e.getValue();
            String base = "players." + e.getKey();
            data.set(base + ".name", pd.getLastName());
            data.set(base + ".ip", pd.getLastIp());
            data.set(base + ".violation-level", pd.getViolationLevel());
        }
        // Punishments
        data.set("punishments", null);
        for (Punishment p : punishments) {
            String base = "punishments." + p.getId();
            data.set(base + ".type", p.getType().name());
            data.set(base + ".target-name", p.getTargetName());
            data.set(base + ".target-uuid", p.getTargetUuid());
            data.set(base + ".target-ip", p.getTargetIp());
            data.set(base + ".operator", p.getOperator());
            data.set(base + ".operator-uuid", p.getOperatorUuid());
            data.set(base + ".start", p.getStart());
            data.set(base + ".end", p.getEnd());
            data.set(base + ".reason", p.getReason());
            data.set(base + ".silent", p.isSilent());
        }
        try { data.save(dataFile); }
        catch (IOException ex) { plugin.getLogger().severe("Failed to save data.yml: " + ex.getMessage()); }
    }

    public void startAutoSave() {
        int interval = plugin.getConfig().getInt("settings.save-interval-seconds", 120);
        Bukkit.getScheduler().runTaskTimer(plugin, this::save, interval * 20L, interval * 20L);
    }

    public void startDecayTask() {
        if (!plugin.getConfig().getBoolean("decay.enabled", true)) return;
        int interval = plugin.getConfig().getInt("decay.decay-interval-seconds", 60);
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            long now = System.currentTimeMillis();
            for (PlayerData pd : players.values()) {
                if (pd.getViolationLevel() <= 0) continue;
                if (now - pd.getLastFlagTime() < interval * 1000L) continue;
                pd.setViolationLevel(pd.getViolationLevel() - 1);
            }
        }, interval * 20L, interval * 20L);
    }

    public void resetPlayerVL(UUID uuid) {
        PlayerData pd = players.get(uuid);
        if (pd != null) pd.resetVL();
        data.set("players." + uuid + ".violation-level", 0);
        save();
    }
}

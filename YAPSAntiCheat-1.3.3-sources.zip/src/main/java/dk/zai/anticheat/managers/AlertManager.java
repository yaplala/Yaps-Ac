package dk.zai.anticheat.managers;

import dk.zai.anticheat.AntiCheatPlugin;
import dk.zai.anticheat.ColorUtil;
import dk.zai.anticheat.data.PlayerData;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.Map;
import java.util.TreeMap;

/**
 * Sends anti-cheat alerts to all players with the anticheat.alerts
 * permission and applies the configured punishment-steps ladder.
 */
public class AlertManager {

    private final AntiCheatPlugin plugin;
    private TreeMap<Integer, String> steps = new TreeMap<>();
    private String postStepBehavior = "MAX_PUNISH";

    public AlertManager(AntiCheatPlugin plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        steps.clear();
        var sec = plugin.getConfig().getConfigurationSection("punishment-steps");
        if (sec != null) {
            for (String k : sec.getKeys(false)) {
                try { steps.put(Integer.parseInt(k), sec.getString(k, "NONE")); }
                catch (NumberFormatException ignored) {}
            }
        }
        postStepBehavior = plugin.getConfig().getString("post-step-behavior", "MAX_PUNISH");
    }

    public void flag(Player player, String checkName, String detail) {
        if (player.hasPermission(plugin.getConfig().getString("settings.bypass-permission", "yaps.bypass"))) {
            return;
        }
        int ping = player.getPing();
        int maxPing = plugin.getConfig().getInt("settings.max-ping", 250);
        if (ping > maxPing) return;

        PlayerData pd = plugin.getDataManager().get(player.getUniqueId());
        pd.setLastName(player.getName());
        if (player.getAddress() != null) {
            pd.setLastIp(player.getAddress().getAddress().getHostAddress());
            plugin.getDataManager().cacheIp(pd.getLastIp(), player.getUniqueId());
        }
        pd.incrementVL(1);

        // Send chat alert to staff
        String alert = plugin.getConfig().getString("messages.alert",
                        "&c[ALERT] %player% flagged %check% | VL: %vl%")
                .replace("%player%", player.getName())
                .replace("%check%", checkName + (detail == null || detail.isEmpty() ? "" : " (" + detail + ")"))
                .replace("%vl%", String.valueOf(pd.getViolationLevel()));
        Component cmp = ColorUtil.toComponent(plugin.getConfig().getString("messages.prefix", "") + alert);
        String perm = plugin.getConfig().getString("settings.alert-permission", "yaps.alerts");
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.hasPermission(perm)) p.sendMessage(cmp);
        }
        Bukkit.getConsoleSender().sendMessage(cmp);

        // Apply punishment step
        applyStep(player, pd.getViolationLevel(), checkName);
    }

    private void applyStep(Player player, int vl, String checkName) {
        String step = resolveStep(vl);
        if (step == null || step.equalsIgnoreCase("NONE")) return;
        String[] parts = step.split(":");
        String action = parts[0].toUpperCase();
        int duration = (parts.length > 1) ? Integer.parseInt(parts[1]) : 0;
        plugin.getPunishmentManager().applyFromAntiCheatStep(player, action, duration, checkName);
    }

    private String resolveStep(int vl) {
        Map.Entry<Integer, String> e = steps.floorEntry(vl);
        if (e != null) return e.getValue();
        if ("REPEAT_LAST".equalsIgnoreCase(postStepBehavior) && !steps.isEmpty())
            return steps.lastEntry().getValue();
        if ("MAX_PUNISH".equalsIgnoreCase(postStepBehavior) && !steps.isEmpty())
            return steps.lastEntry().getValue();
        return null;
    }
}

package dk.zai.anticheat.managers;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Parses AdvancedBan-style duration strings:
 *   Xmo, Xd, Xh, Xm, Xs  (also "perma" = -1)
 * Examples: "1mo", "2d", "3h", "30m", "45s", "1mo2d3h"
 */
public final class TimeParser {

    private static final Pattern PATTERN = Pattern.compile(
            "(\\d+)\\s*(mo|d|h|m|s)", Pattern.CASE_INSENSITIVE);

    private TimeParser() {}

    /** Returns duration in milliseconds, or -1 for "perma", or 0 if unparseable. */
    public static long parseToMillis(String input) {
        if (input == null) return 0L;
        String trimmed = input.trim();
        if (trimmed.equalsIgnoreCase("perma") || trimmed.equalsIgnoreCase("permanent")) return -1L;

        Matcher m = PATTERN.matcher(trimmed);
        long total = 0L;
        boolean found = false;
        while (m.find()) {
            found = true;
            long n = Long.parseLong(m.group(1));
            String unit = m.group(2).toLowerCase();
            switch (unit) {
                case "mo" -> total += n * 30L * 24L * 60L * 60L * 1000L;
                case "d"  -> total += n * 24L * 60L * 60L * 1000L;
                case "h"  -> total += n * 60L * 60L * 1000L;
                case "m"  -> total += n * 60L * 1000L;
                case "s"  -> total += n * 1000L;
            }
        }
        return found ? total : 0L;
    }

    public static long parseToSeconds(String input) {
        long ms = parseToMillis(input);
        if (ms < 0) return -1L;
        return ms / 1000L;
    }

    /** Formats a remaining-millis value using the configured time layouts. */
    public static String formatDuration(long remainingMillis, LayoutsManager layouts) {
        if (remainingMillis < 0) return "Permanent";
        if (remainingMillis == 0) return "0 seconds";

        long totalSec = remainingMillis / 1000L;
        long days = totalSec / 86400L;
        long hours = (totalSec % 86400L) / 3600L;
        long mins = (totalSec % 3600L) / 60L;
        long secs = totalSec % 60L;

        String layout;
        if (days > 0) layout = layouts.getTimeLayoutD();
        else if (hours > 0) layout = layouts.getTimeLayoutH();
        else if (mins > 0) layout = layouts.getTimeLayoutM();
        else layout = layouts.getTimeLayoutS();

        return layout
                .replace("%D%", String.valueOf(days))
                .replace("%H%", String.valueOf(hours))
                .replace("%M%", String.valueOf(mins))
                .replace("%S%", String.valueOf(secs));
    }
}

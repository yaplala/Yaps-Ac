package dk.zai.anticheat.managers;

import dk.zai.anticheat.AntiCheatPlugin;
import dk.zai.anticheat.ColorUtil;
import dk.zai.anticheat.data.Punishment;
import dk.zai.anticheat.data.PunishmentType;
import net.kyori.adventure.text.Component;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * Loads Messages.yml + Layouts.yml and renders punishment messages.
 * Supports both legacy &-codes and MiniMessage tags.
 *
 * Variables available everywhere:
 *   %PREFIX%, %OPERATOR%, %NAME%, %REASON%, %DURATION%, %DATE%,
 *   %ID%, %HEXID%, %COUNT%, %MAX%, %PAGE%, %PAGES%, %IP%, %BANNED%,
 *   %MUTED%, %UNTIL%, %TYPE%, %PLAYER%, %CHECK%, %VL%
 */
public class LayoutsManager {

    private final AntiCheatPlugin plugin;
    private FileConfiguration messages;
    private FileConfiguration layouts;
    private final SimpleDateFormat dateFormat;

    public LayoutsManager(AntiCheatPlugin plugin) {
        this.plugin = plugin;
        String fmt = plugin.getConfig().getString("punishment.date-format", "dd.MM.yyyy-HH:mm");
        this.dateFormat = new SimpleDateFormat(fmt);
        load();
    }

    public void load() {
        File msgFile = new File(plugin.getDataFolder(), "Messages.yml");
        if (!msgFile.exists()) plugin.saveResource("Messages.yml", false);
        messages = YamlConfiguration.loadConfiguration(msgFile);

        File layFile = new File(plugin.getDataFolder(), "Layouts.yml");
        if (!layFile.exists()) plugin.saveResource("Layouts.yml", false);
        layouts = YamlConfiguration.loadConfiguration(layFile);
    }

    public String getPrefix() {
        return messages.getString("General.Prefix", "&c&lZAC &8»");
    }

    public String getNoPerms() {
        return messages.getString("General.NoPerms", "&cYou don't have perms for that!");
    }

    public String getTimeLayoutD() {
        return messages.getString("General.TimeLayoutD", "%D%d %H%h %M%m %S%s");
    }
    public String getTimeLayoutH() {
        return messages.getString("General.TimeLayoutH", "%H%h %M%m %S%s");
    }
    public String getTimeLayoutM() {
        return messages.getString("General.TimeLayoutM", "%M%m %S%s");
    }
    public String getTimeLayoutS() {
        return messages.getString("General.TimeLayoutS", "%S%s");
    }

    public String getMessage(String path) {
        return messages.getString(path, "&cMissing message: " + path);
    }

    public List<String> getMessageList(String path) {
        return messages.getStringList(path);
    }

    /** Returns the custom layout from Layouts.yml if it exists, otherwise null. */
    public List<String> getCustomMessageLayout(String name) {
        List<String> list = layouts.getStringList("Message." + name);
        return list.isEmpty() ? null : list;
    }

    public List<String> getCustomTimeLayout(String name) {
        return layouts.getStringList("Time." + name);
    }

    public String format(String input, Punishment p) {
        if (input == null) return "";
        String out = input;
        out = out.replace("%PREFIX%", getPrefix());
        out = out.replace("%OPERATOR%", p == null ? "" : p.getOperator());
        out = out.replace("%NAME%", p == null ? "" : p.getTargetName());
        out = out.replace("%REASON%", p == null ? "" : p.getReason());
        out = out.replace("%DATE%", p == null ? "" : dateFormat.format(new Date(p.getStart())));
        out = out.replace("%ID%", p == null ? "" : String.valueOf(p.getId()));
        out = out.replace("%HEXID%", p == null ? "" : p.getHexId());
        out = out.replace("%IP%", p == null ? "" : p.getTargetIp());

        String duration;
        if (p == null) duration = "";
        else if (p.isPermanent()) duration = "Permanent";
        else duration = TimeParser.formatDuration(p.getRemainingMillis(), this);
        out = out.replace("%DURATION%", duration);
        return out;
    }

    /** Renders a multi-line layout (List<String>) as a single Component separated by newlines. */
    public Component renderLayout(List<String> lines, Punishment p) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < lines.size(); i++) {
            if (i > 0) sb.append("\n");
            sb.append(format(lines.get(i), p));
        }
        return ColorUtil.toComponent(sb.toString());
    }

    public Component renderMessage(String path, Punishment p) {
        return ColorUtil.toComponent(format(getMessage(path), p));
    }

    public Component renderMessage(String path) {
        return ColorUtil.toComponent(format(getMessage(path), null));
    }

    public Component renderList(List<String> lines) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < lines.size(); i++) {
            if (i > 0) sb.append("\n");
            sb.append(format(lines.get(i), null));
        }
        return ColorUtil.toComponent(sb.toString());
    }

    public SimpleDateFormat getDateFormat() { return dateFormat; }
}

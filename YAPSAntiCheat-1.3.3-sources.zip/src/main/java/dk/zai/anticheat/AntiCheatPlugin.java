package dk.zai.anticheat;

import dk.zai.anticheat.checks.CheckContainer;
import dk.zai.anticheat.commands.AntiCheatCommand;
import dk.zai.anticheat.commands.PunishmentCommands;
import dk.zai.anticheat.gui.GUIListener;
import dk.zai.anticheat.gui.YapsGUI;
import dk.zai.anticheat.listeners.*;
import dk.zai.anticheat.managers.*;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * YAPS AntiCheat - all-in-one anti-cheat for Paper 1.21.11.
 *
 * Features:
 *  - 18 detection modules (combat / movement / player / exploits)
 *  - AdvancedBan 2.3.0-style punishment system (ban, tempban, ipban,
 *    tempipban, mute, tempmute, kick, warn, tempwarn, note, unban,
 *    unmute, unwarn, unnote, unpunish, change-reason, banlist,
 *    history, warns, notes, check)
 *  - Admin GUI (Players / Checks / Active Bans / Quick punish buttons)
 *  - Layouts system (Messages.yml + Layouts.yml) with variables
 *  - Permission nodes (ab.*) with duration caps and exempt players
 *  - Persistent storage in data.yml (survives restarts)
 */
public final class AntiCheatPlugin extends JavaPlugin {

    private DataManager dataManager;
    private PunishmentManager punishmentManager;
    private PermissionManager permissionManager;
    private LayoutsManager layoutsManager;
    private AlertManager alertManager;
    private CheckContainer checks;
    private YapsGUI gui;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        saveResource("Messages.yml", false);
        saveResource("Layouts.yml", false);

        this.dataManager = new DataManager(this);
        this.layoutsManager = new LayoutsManager(this);
        this.permissionManager = new PermissionManager(this);
        this.punishmentManager = new PunishmentManager(this);
        this.alertManager = new AlertManager(this);
        this.checks = new CheckContainer(this);
        this.gui = new YapsGUI(this);

        var pm = getServer().getPluginManager();
        pm.registerEvents(new MoveListener(this), this);
        pm.registerEvents(new CombatListener(this), this);
        pm.registerEvents(new WindChargeListener(this), this);
        pm.registerEvents(new ChatListener(this), this);
        pm.registerEvents(new LoginListener(this), this);
        pm.registerEvents(new PlayerWorldListener(this), this);
        pm.registerEvents(new GUIListener(this, gui), this);

        // Anti-cheat admin commands (/yaps)
        AntiCheatCommand acCmd = new AntiCheatCommand(this);
        getCommand("yaps").setExecutor(acCmd);
        getCommand("yaps").setTabCompleter(acCmd);

        // Punishment commands (single dispatcher)
        PunishmentCommands punCmd = new PunishmentCommands(this);
        for (String name : new String[]{
                "ban", "tempban", "ipban", "banip", "ban-ip", "tempipban", "tipban",
                "mute", "tempmute", "kick", "warn", "tempwarn", "note",
                "unban", "unmute", "unwarn", "unnote", "unpunish", "change-reason",
                "banlist", "history", "warns", "notes", "check"
        }) {
            if (getCommand(name) != null) {
                getCommand(name).setExecutor(punCmd);
                getCommand(name).setTabCompleter(punCmd);
            }
        }

        dataManager.startAutoSave();
        dataManager.startDecayTask();

        getLogger().info("YAPS AntiCheat enabled with " + checks.all().size()
                + " checks, AdvancedBan-style punishment system, and admin GUI.");
    }

    @Override
    public void onDisable() {
        if (dataManager != null) dataManager.save();
        getLogger().info("YAPS AntiCheat disabled.");
    }

    /**
     * Reload everything from disk: config.yml + Messages.yml + Layouts.yml,
     * then refresh all in-memory check settings.
     */
    public void reloadAll() {
        reloadConfig();
        layoutsManager.load();
        alertManager.reload();
        checks.reloadAll();
    }

    /**
     * Re-apply in-memory config to all checks WITHOUT reloading config.yml
     * from disk. Used after a single check has been toggled via the GUI
     * so the toggle isn't overwritten.
     */
    public void refreshChecks() {
        checks.reloadAll();
    }

    public DataManager getDataManager() { return dataManager; }
    public PunishmentManager getPunishmentManager() { return punishmentManager; }
    public PermissionManager getPermissionManager() { return permissionManager; }
    public LayoutsManager getLayoutsManager() { return layoutsManager; }
    public AlertManager getAlertManager() { return alertManager; }
    public CheckContainer getChecks() { return checks; }
    public YapsGUI getGui() { return gui; }
}
